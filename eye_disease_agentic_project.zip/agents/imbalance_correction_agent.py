class ImbalanceCorrectionAgent:
    def suggest(self, audit_result):
        counts = audit_result["class_counts"]

        # If already balanced
        if audit_result["is_balanced"]:
            return "Dataset is balanced. No imbalance correction required."

        # Remove invalid labels if any
        valid_counts = {k: v for k, v in counts.items() if k}

        max_count = max(valid_counts.values())

        suggestions = []

        for cls, count in valid_counts.items():
            if count < 0.75 * max_count:
                needed = max_count - count

                suggestions.append(
                    f"{cls}: add/augment approximately {needed} images "
                    f"(current: {count}, target: {max_count})."
                )

        # If no class needs correction (edge case)
        if not suggestions:
            return "Minor imbalance detected. Consider using class weights only."

        return "\n".join(suggestions)