class DecisionAgent:
    BALANCED_THRESHOLD = 0.75
    CLASS_WEIGHT_THRESHOLD = 0.50
    SAMPLER_THRESHOLD = 0.25

    HIGH_CONFIDENCE_THRESHOLD = 0.90
    MODERATE_CONFIDENCE_THRESHOLD = 0.70

    def decide_balance_strategy(self, audit_result):
        ratio = audit_result["balance_ratio"]

        if audit_result["is_balanced"]:
            return {
                "status": "balanced",
                "action": "Proceed directly to classification."
            }

        if ratio >= self.CLASS_WEIGHT_THRESHOLD:
            action = "Use class weights."
        elif ratio >= self.SAMPLER_THRESHOLD:
            action = "Use weighted sampler and class weights."
        else:
            action = "Use targeted augmentation, weighted sampler, and class weights."

        return {
            "status": "imbalanced",
            "action": action
        }

    def decide_prediction_reliability(self, confidence):
        if confidence >= self.HIGH_CONFIDENCE_THRESHOLD:
            return "High confidence prediction"

        if confidence >= self.MODERATE_CONFIDENCE_THRESHOLD:
            return "Moderate confidence prediction; Grad-CAM explanation recommended"

        return "Low confidence prediction; expert review recommended"