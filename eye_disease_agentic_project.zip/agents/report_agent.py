import os
import json


class ReportAgent:
    def make_json_safe(self, obj):
        """
        Convert non-JSON-safe values into normal Python types.
        """
        if isinstance(obj, dict):
            return {k: self.make_json_safe(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self.make_json_safe(v) for v in obj]
        if hasattr(obj, "item"):
            return obj.item()
        return obj

    def save_report(
        self,
        audit,
        balance_decision,
        imbalance_suggestion,
        predictions,
        evaluation,
        performance_metrics=None,
        agentic_evaluation=None,
        output_path="outputs/agentic_report.txt"
    ):

        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        lines = []
        lines.append("AGENTIC EYE DISEASE CLASSIFICATION REPORT")
        lines.append("=" * 55)

        # ---------------- DATA ----------------
        lines.append("\n1. DATA AGENT")
        lines.append(f"Total images: {audit['total_images']}")
        lines.append(f"Class counts: {audit['class_counts']}")
        lines.append(f"Balance ratio: {audit['balance_ratio']:.2f}")
        lines.append(f"Balanced: {audit['is_balanced']}")

        # ---------------- DECISION ----------------
        lines.append("\n2. DECISION AGENT")
        lines.append(f"Dataset status: {balance_decision['status']}")
        lines.append(f"Action: {balance_decision['action']}")

        # ---------------- IMBALANCE ----------------
        lines.append("\n3. IMBALANCE CORRECTION AGENT")
        lines.append(imbalance_suggestion)

        # ---------------- CLASSIFICATION ----------------
        lines.append("\n4. CLASSIFICATION AGENT")
        for p in predictions:
            lines.append(
                f"{os.path.basename(p['image_path'])} → "
                f"True: {p.get('true_label', 'N/A')} | "
                f"Predicted: {p['prediction']} | "
                f"Confidence: {p['confidence']:.2f} | "
                f"Reliability: {p['reliability']} | "
                f"Grad-CAM: {p.get('gradcam_path', None)}"
            )

        # ---------------- EVALUATION ----------------
        lines.append("\n5. EVALUATION AGENT")
        lines.append(f"Total predictions: {evaluation['total_predictions']}")
        lines.append(f"Predicted class counts: {evaluation['predicted_class_counts']}")
        lines.append(f"Average confidence: {evaluation['average_confidence']:.2f}")
        lines.append(f"Confidence groups: {evaluation['confidence_groups']}")
        lines.append(f"Confidence correctness: {evaluation['confidence_correctness']}")

        if "confidence_accuracy" in evaluation:
            lines.append(f"Confidence accuracy: {evaluation['confidence_accuracy']}")

        # ---------------- PERFORMANCE METRICS ----------------
        if performance_metrics is not None:
            lines.append("\n6. PERFORMANCE METRICS")
            lines.append(f"Accuracy: {performance_metrics['accuracy']:.2f}")
            lines.append(f"Precision: {performance_metrics['precision']:.2f}")
            lines.append(f"Recall: {performance_metrics['recall']:.2f}")
            lines.append(f"F1-score: {performance_metrics['f1_score']:.2f}")
            lines.append(f"Labels: {performance_metrics['labels']}")
            lines.append("Confusion Matrix:")
            lines.append(str(performance_metrics["confusion_matrix"]))
            lines.append("\nClassification Report:")
            lines.append(performance_metrics["classification_report"])

        # ---------------- AGENTIC EVALUATION ----------------
        if agentic_evaluation is not None:
            lines.append("\n7. AGENTIC SYSTEM EVALUATION")
            lines.append(f"Balance ratio: {agentic_evaluation['balance_ratio']:.2f}")
            lines.append(f"Expected action: {agentic_evaluation['expected_action']}")
            lines.append(f"Agent action: {agentic_evaluation['agent_action']}")
            lines.append(f"Decision correct: {agentic_evaluation['decision_correct']}")
            lines.append(f"Decision accuracy: {agentic_evaluation['decision_accuracy']:.2f}")

        # ---------------- XAI ----------------
        lines.append("\n8. XAI AGENT")
        lines.append(
            "Grad-CAM visual explanations were generated for low- and moderate-confidence classified images."
        )

        report_text = "\n".join(lines)

        # Save text report
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(report_text)

        # Save JSON report
        json_data = {
            "audit": audit,
            "balance_decision": balance_decision,
            "imbalance_suggestion": imbalance_suggestion,
            "predictions": predictions,
            "evaluation": evaluation,
            "performance_metrics": performance_metrics,
            "agentic_evaluation": agentic_evaluation
        }

        json_path = output_path.replace(".txt", ".json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(self.make_json_safe(json_data), f, indent=4)

        return report_text