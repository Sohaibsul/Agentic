import os
import time
from crewai import Agent, Task, Crew, Process

# dummy key (Ollama use ho raha hai)
os.environ["OPENAI_API_KEY"] = "none"


# -------- Extract only useful report parts --------
def extract_summary_for_crewai(report_text):
    keep_sections = [
        "1. DATA AGENT",
        "2. DECISION AGENT",
        "3. IMBALANCE CORRECTION AGENT",
        "5. EVALUATION AGENT",
        "6. PERFORMANCE METRICS",
        "7. AGENTIC SYSTEM EVALUATION",
        "8. XAI AGENT"
    ]

    lines = report_text.splitlines()
    selected = []
    keep = False

    for line in lines:
        stripped = line.strip()

        if any(stripped.startswith(sec) for sec in keep_sections):
            keep = True
            selected.append(line)
            continue

        if stripped.startswith("4. CLASSIFICATION AGENT"):
            keep = False
            continue

        if keep:
            selected.append(line)

    return "\n".join(selected)


# -------- MAIN CREW FUNCTION --------
def run_crewai_report(agentic_report_text):

    llm_model = "ollama/llama3.2:3b"

    report_for_llm = extract_summary_for_crewai(agentic_report_text)

    # ---------------- AGENTS ----------------
    data_agent = Agent(
        role="Data Auditor",
        goal="Summarize dataset balance using only the given report.",
        backstory="Expert in medical dataset auditing and class distribution analysis.",
        llm=llm_model,
        verbose=True,
        allow_delegation=False,
        max_iter=1
    )

    decision_agent = Agent(
        role="Decision Analyst",
        goal="Summarize decision agent action accurately.",
        backstory="Expert in rule-based AI decision systems for healthcare.",
        llm=llm_model,
        verbose=True,
        allow_delegation=False,
        max_iter=1
    )

    evaluation_agent = Agent(
        role="Model Evaluation Expert",
        goal="Summarize model performance metrics correctly.",
        backstory="Expert in ML metrics like accuracy, precision, recall, and F1-score.",
        llm=llm_model,
        verbose=True,
        allow_delegation=False,
        max_iter=1
    )

    xai_agent = Agent(
        role="XAI Specialist",
        goal="Explain Grad-CAM usage clearly.",
        backstory="Expert in explainable AI for medical imaging systems.",
        llm=llm_model,
        verbose=True,
        allow_delegation=False,
        max_iter=1
    )

    report_agent = Agent(
        role="Academic Writer",
        goal="Write final IEEE-style paragraph using only report facts.",
        backstory="Experienced academic writer in medical AI research.",
        llm=llm_model,
        verbose=True,
        allow_delegation=False,
        max_iter=1
    )

    # ---------------- TASKS ----------------
    t1 = Task(
        description=f"""
Write exactly 2 lines about dataset balance.

Rules:
- Use only values from report
- Do NOT mention augmentation if dataset is balanced

REPORT:
{report_for_llm}
""",
        expected_output="2 lines dataset summary",
        agent=data_agent
    )

    t2 = Task(
        description=f"""
Write exactly 2 lines about Decision Agent action.

Rules:
- If action is 'Proceed directly to classification', clearly say no imbalance correction needed

REPORT:
{report_for_llm}
""",
        expected_output="2 lines decision summary",
        agent=decision_agent,
        context=[t1]
    )

    t3 = Task(
        description=f"""
Write exactly 3 lines summarizing model performance.

Include:
- Accuracy
- Precision
- Recall
- F1-score

Do NOT calculate new values.

REPORT:
{report_for_llm}
""",
        expected_output="3 lines performance summary",
        agent=evaluation_agent,
        context=[t1, t2]
    )

    t4 = Task(
        description=f"""
Write exactly 2 lines explaining Grad-CAM.

Rules:
- Mention interpretability
- Mention low-confidence predictions support

REPORT:
{report_for_llm}
""",
        expected_output="2 lines XAI summary",
        agent=xai_agent,
        context=[t3]
    )

    t5 = Task(
        description=f"""
Write ONE IEEE-style paragraph using only report values.

Include:
- dataset size
- balance ratio
- decision action
- performance metrics
- decision accuracy
- Grad-CAM usage

Strict:
- Do NOT hardcode values
- Do NOT invent anything

REPORT:
{report_for_llm}
""",
        expected_output="Final paragraph",
        agent=report_agent,
        context=[t1, t2, t3, t4]
    )

    # ---------------- CREW ----------------
    crew = Crew(
        agents=[data_agent, decision_agent, evaluation_agent, xai_agent, report_agent],
        tasks=[t1, t2, t3, t4, t5],
        process=Process.sequential,
        verbose=True
    )

    # ---------------- RUN ----------------
    try:
        result = crew.kickoff()
    except Exception as e:
        print("CrewAI error:", e)
        time.sleep(10)
        result = crew.kickoff()

    return str(result)