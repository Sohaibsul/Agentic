from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)


class EvaluationAgent:
    HIGH_CONFIDENCE_THRESHOLD = 0.90
    MODERATE_CONFIDENCE_THRESHOLD = 0.70

    def summarize_predictions(self, predictions):
        total = len(predictions)

        class_counts = {}
        confidence_sum = 0.0

        high_conf = 0
        moderate_conf = 0
        low_conf = 0

        correct_high = 0
        correct_moderate = 0
        correct_low = 0

        for p in predictions:
            pred = p["prediction"]
            conf = float(p["confidence"])

            class_counts[pred] = class_counts.get(pred, 0) + 1
            confidence_sum += conf

            is_correct = p.get("true_label") == p.get("prediction")

            if conf >= self.HIGH_CONFIDENCE_THRESHOLD:
                high_conf += 1
                if is_correct:
                    correct_high += 1
            elif conf >= self.MODERATE_CONFIDENCE_THRESHOLD:
                moderate_conf += 1
                if is_correct:
                    correct_moderate += 1
            else:
                low_conf += 1
                if is_correct:
                    correct_low += 1

        avg_confidence = confidence_sum / total if total else 0.0

        return {
            "total_predictions": total,
            "predicted_class_counts": class_counts,
            "average_confidence": round(avg_confidence, 4),
            "confidence_groups": {
                "high_confidence": high_conf,
                "moderate_confidence": moderate_conf,
                "low_confidence": low_conf
            },
            "confidence_correctness": {
                "high_confidence_correct": correct_high,
                "moderate_confidence_correct": correct_moderate,
                "low_confidence_correct": correct_low
            },
            "confidence_accuracy": {
                "high_confidence_accuracy": round(correct_high / high_conf, 4) if high_conf else 0.0,
                "moderate_confidence_accuracy": round(correct_moderate / moderate_conf, 4) if moderate_conf else 0.0,
                "low_confidence_accuracy": round(correct_low / low_conf, 4) if low_conf else 0.0
            }
        }

    def evaluate_with_ground_truth(self, predictions):
        if not predictions:
            return {
                "labels": [],
                "accuracy": 0.0,
                "precision": 0.0,
                "recall": 0.0,
                "f1_score": 0.0,
                "confusion_matrix": [],
                "classification_report": "No predictions available."
            }

        y_true = [p["true_label"] for p in predictions]
        y_pred = [p["prediction"] for p in predictions]

        labels = sorted(list(set(y_true + y_pred)))

        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(
            y_true, y_pred, average="weighted", zero_division=0
        )
        recall = recall_score(
            y_true, y_pred, average="weighted", zero_division=0
        )
        f1 = f1_score(
            y_true, y_pred, average="weighted", zero_division=0
        )

        cm = confusion_matrix(y_true, y_pred, labels=labels)

        report = classification_report(
            y_true,
            y_pred,
            labels=labels,
            zero_division=0
        )

        return {
            "labels": labels,
            "accuracy": round(accuracy, 4),
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1, 4),
            "confusion_matrix": cm.tolist(),
            "classification_report": report
        }

    def evaluate_agentic_decision(self, audit_result, balance_decision):
        ratio = audit_result["balance_ratio"]
        is_balanced = audit_result["is_balanced"]
        action = balance_decision["action"]

        if is_balanced:
            expected_action = "Proceed directly to classification."
        elif ratio >= 0.50:
            expected_action = "Use class weights."
        elif ratio >= 0.25:
            expected_action = "Use weighted sampler and class weights."
        else:
            expected_action = "Use targeted augmentation, weighted sampler, and class weights."

        decision_correct = action == expected_action

        return {
            "balance_ratio": ratio,
            "expected_action": expected_action,
            "agent_action": action,
            "decision_correct": decision_correct,
            "decision_accuracy": 1.0 if decision_correct else 0.0
        }