from src.gradcam import save_gradcam


class XAIAgent:
    def explain(self, image_path, model, device, id2label):
        return save_gradcam(
            image_path=image_path,
            model=model,
            device=device,
            id2label=id2label,
            output_dir="outputs/gradcam"
        )