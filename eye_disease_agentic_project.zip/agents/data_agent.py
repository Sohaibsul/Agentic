from collections import Counter
from pathlib import Path


class DataAgent:
    def __init__(self, image_folder="test_images"):
        self.image_folder = Path(image_folder)

    def collect_images(self):
        """
        Collect all image files recursively from folder
        """
        exts = [".jpg", ".jpeg", ".png"]
        return [
            p for p in self.image_folder.rglob("*")
            if p.suffix.lower() in exts
        ]

    def infer_label_from_path(self, image_path):
        """
        Extract class label from parent folder name
        Example: test_images/cataract/img1.jpg → cataract
        """
        return Path(image_path).parent.name.lower()

    def audit(self):
        """
        Analyze dataset distribution and balance
        """
        images = self.collect_images()

        # labels from folder names
        labels = [self.infer_label_from_path(p) for p in images]

        # count per class
        counts = dict(Counter(labels))

        # remove empty/invalid labels if any
        counts = {k: v for k, v in counts.items() if k}

        # balance calculation
        if counts:
            min_count = min(counts.values())
            max_count = max(counts.values())
            balance_ratio = round(min_count / max_count, 2)
            is_balanced = balance_ratio >= 0.90
        else:
            balance_ratio = 0.0
            is_balanced = False

        return {
            "total_images": len(images),
            "class_counts": counts,
            "balance_ratio": balance_ratio,
            "is_balanced": is_balanced,
            "images": [str(p) for p in images]
        }