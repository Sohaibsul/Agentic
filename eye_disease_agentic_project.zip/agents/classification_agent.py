from src.predict import load_model, predict_image


class ClassificationAgent:
    def __init__(self):
        self.model, self.device, self.id2label = load_model()

    def classify(self, image_path):
        return predict_image(
            image_path=image_path,
            model=self.model,
            device=self.device,
            id2label=self.id2label
        )