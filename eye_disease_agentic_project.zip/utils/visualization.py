import os
import csv
import numpy as np
import matplotlib

matplotlib.use("Agg")  # Fix Tkinter/main-thread error

import matplotlib.pyplot as plt


def save_confusion_matrix(confusion_matrix, labels, output_path="outputs/confusion_matrix.png"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    cm = np.array(confusion_matrix)

    plt.figure(figsize=(8, 6))
    plt.imshow(cm)
    plt.title("Confusion Matrix")
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.xticks(range(len(labels)), labels, rotation=45, ha="right")
    plt.yticks(range(len(labels)), labels)

    for i in range(len(labels)):
        for j in range(len(labels)):
            plt.text(j, i, cm[i, j], ha="center", va="center")

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close("all")

    return output_path


def save_class_distribution_chart(class_counts, output_path="outputs/class_distribution.png"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    labels = list(class_counts.keys())
    counts = list(class_counts.values())

    plt.figure(figsize=(8, 5))
    plt.bar(labels, counts)
    plt.title("Dataset Class Distribution")
    plt.xlabel("Class")
    plt.ylabel("Number of Images")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close("all")

    return output_path


def save_results_table_csv(performance_metrics, agentic_evaluation=None, output_path="outputs/results_table.csv"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    rows = [
        ["Metric", "Value"],
        ["Accuracy", f"{performance_metrics['accuracy']:.2f}"],
        ["Precision", f"{performance_metrics['precision']:.2f}"],
        ["Recall", f"{performance_metrics['recall']:.2f}"],
        ["F1-score", f"{performance_metrics['f1_score']:.2f}"],
    ]

    if agentic_evaluation is not None:
        rows.append(["Decision Accuracy", f"{agentic_evaluation['decision_accuracy']:.2f}"])

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(rows)

    return output_path