import json
import torch
from PIL import Image
from torchvision import transforms

from src.model import EnhancedEDDNet
from src.preprocess import enhance_fundus


def load_labels(label_path="model/label_map.json"):
    with open(label_path, "r") as f:
        data = json.load(f)

    id2label = data["id2label"]
    return {int(k): v for k, v in id2label.items()}


def load_model(model_path="model/final_model_after_training.pth"):
    device = "cuda" if torch.cuda.is_available() else "cpu"

    id2label = load_labels()
    model = EnhancedEDDNet(num_classes=len(id2label)).to(device)

    ckpt = torch.load(model_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    return model, device, id2label


def get_transform():
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(
            [0.485, 0.456, 0.406],
            [0.229, 0.224, 0.225]
        )
    ])


def predict_image(image_path, model, device, id2label):
    img = Image.open(image_path).convert("RGB")
    img = enhance_fundus(img)

    transform = get_transform()
    tensor = transform(img).unsqueeze(0).to(device)

    with torch.no_grad():
        output = model(tensor)
        probs = torch.softmax(output, dim=1)
        pred_id = probs.argmax(dim=1).item()
        confidence = probs[0][pred_id].item()

    return {
        "image_path": image_path,
        "pred_id": pred_id,
        "prediction": id2label[pred_id],
        "confidence": confidence,
        "probabilities": {
            id2label[i]: float(probs[0][i].item())
            for i in range(len(id2label))
        }
    }