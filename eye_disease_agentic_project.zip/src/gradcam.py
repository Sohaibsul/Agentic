import os
import numpy as np
import torch
import matplotlib

matplotlib.use("Agg")  # Fix Tkinter/main-thread error

import matplotlib.pyplot as plt
from PIL import Image

from src.preprocess import enhance_fundus
from src.predict import get_transform


class GradCAM:
    def __init__(self, model, target_layer):
        self.model = model
        self.target_layer = target_layer
        self.activations = None
        self.gradients = None

        self.forward_handle = self.target_layer.register_forward_hook(
            self.forward_hook
        )
        self.backward_handle = self.target_layer.register_full_backward_hook(
            self.backward_hook
        )

    def forward_hook(self, module, inputs, output):
        self.activations = output

    def backward_hook(self, module, grad_input, grad_output):
        self.gradients = grad_output[0]

    def generate(self, image_tensor, pred_class):
        self.model.eval()

        output = self.model(image_tensor)
        score = output[:, pred_class]

        self.model.zero_grad()
        score.backward()

        if self.activations is None or self.gradients is None:
            raise RuntimeError("Grad-CAM hooks failed.")

        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1).squeeze()

        cam = torch.relu(cam)
        cam = cam.detach().cpu().numpy()

        cam_min = cam.min()
        cam_max = cam.max()

        if cam_max - cam_min < 1e-8:
            cam = np.zeros_like(cam)
        else:
            cam = (cam - cam_min) / (cam_max - cam_min)

        return cam

    def remove_hooks(self):
        self.forward_handle.remove()
        self.backward_handle.remove()


def save_gradcam(image_path, model, device, id2label, output_dir="outputs/gradcam"):
    os.makedirs(output_dir, exist_ok=True)

    original = Image.open(image_path).convert("RGB")
    enhanced = enhance_fundus(original)

    transform = get_transform()
    image_tensor = transform(enhanced).unsqueeze(0).to(device)

    model.eval()

    with torch.no_grad():
        output = model(image_tensor)
        probs = torch.softmax(output, dim=1)
        pred_id = probs.argmax(dim=1).item()
        confidence = probs[0][pred_id].item()

    gradcam = GradCAM(model, model.block4[3])

    try:
        cam = gradcam.generate(image_tensor, pred_id)
    finally:
        gradcam.remove_hooks()

    img = np.array(enhanced.resize((224, 224))) / 255.0

    base_name = os.path.splitext(os.path.basename(image_path))[0]
    save_path = os.path.join(output_dir, f"{base_name}_gradcam.png")

    plt.figure(figsize=(8, 4))

    plt.subplot(1, 2, 1)
    plt.imshow(img)
    plt.title("Enhanced Fundus")
    plt.axis("off")

    plt.subplot(1, 2, 2)
    plt.imshow(img)
    plt.imshow(cam, cmap="jet", alpha=0.45)
    plt.title(f"Grad-CAM\nPred: {id2label[pred_id]} ({confidence:.2f})")
    plt.axis("off")

    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close("all")

    return {
        "gradcam_path": save_path,
        "prediction": id2label[pred_id],
        "confidence": confidence
    }